#include "WeatherView.h"
#include "Menu.h"

WeatherView::WeatherView(Menu* menu, int& buttonFlags, NetworkInterface* network, const std::string& longitude, const std::string& latitude)
    : View(menu, buttonFlags), network(network), lastUpdate(0), longitude(longitude), latitude(latitude) {
        // create a thread that runs update() every 15 mins
    }

const char* SSL_CA_PEM1 = 
"-----BEGIN CERTIFICATE-----\n"
"MIIFBjCCAu6gAwIBAgIRAIp9PhPWLzDvI4a9KQdrNPgwDQYJKoZIhvcNAQELBQAw\n"
"TzELMAkGA1UEBhMCVVMxKTAnBgNVBAoTIEludGVybmV0IFNlY3VyaXR5IFJlc2Vh\n"
"cmNoIEdyb3VwMRUwEwYDVQQDEwxJU1JHIFJvb3QgWDEwHhcNMjQwMzEzMDAwMDAw\n"
"WhcNMjcwMzEyMjM1OTU5WjAzMQswCQYDVQQGEwJVUzEWMBQGA1UEChMNTGV0J3Mg\n"
"RW5jcnlwdDEMMAoGA1UEAxMDUjExMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB\n"
"CgKCAQEAuoe8XBsAOcvKCs3UZxD5ATylTqVhyybKUvsVAbe5KPUoHu0nsyQYOWcJ\n"
"DAjs4DqwO3cOvfPlOVRBDE6uQdaZdN5R2+97/1i9qLcT9t4x1fJyyXJqC4N0lZxG\n"
"AGQUmfOx2SLZzaiSqhwmej/+71gFewiVgdtxD4774zEJuwm+UE1fj5F2PVqdnoPy\n"
"6cRms+EGZkNIGIBloDcYmpuEMpexsr3E+BUAnSeI++JjF5ZsmydnS8TbKF5pwnnw\n"
"SVzgJFDhxLyhBax7QG0AtMJBP6dYuC/FXJuluwme8f7rsIU5/agK70XEeOtlKsLP\n"
"Xzze41xNG/cLJyuqC0J3U095ah2H2QIDAQABo4H4MIH1MA4GA1UdDwEB/wQEAwIB\n"
"hjAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwEwEgYDVR0TAQH/BAgwBgEB\n"
"/wIBADAdBgNVHQ4EFgQUxc9GpOr0w8B6bJXELbBeki8m47kwHwYDVR0jBBgwFoAU\n"
"ebRZ5nu25eQBc4AIiMgaWPbpm24wMgYIKwYBBQUHAQEEJjAkMCIGCCsGAQUFBzAC\n"
"hhZodHRwOi8veDEuaS5sZW5jci5vcmcvMBMGA1UdIAQMMAowCAYGZ4EMAQIBMCcG\n"
"A1UdHwQgMB4wHKAaoBiGFmh0dHA6Ly94MS5jLmxlbmNyLm9yZy8wDQYJKoZIhvcN\n"
"AQELBQADggIBAE7iiV0KAxyQOND1H/lxXPjDj7I3iHpvsCUf7b632IYGjukJhM1y\n"
"v4Hz/MrPU0jtvfZpQtSlET41yBOykh0FX+ou1Nj4ScOt9ZmWnO8m2OG0JAtIIE38\n"
"01S0qcYhyOE2G/93ZCkXufBL713qzXnQv5C/viOykNpKqUgxdKlEC+Hi9i2DcaR1\n"
"e9KUwQUZRhy5j/PEdEglKg3l9dtD4tuTm7kZtB8v32oOjzHTYw+7KdzdZiw/sBtn\n"
"UfhBPORNuay4pJxmY/WrhSMdzFO2q3Gu3MUBcdo27goYKjL9CTF8j/Zz55yctUoV\n"
"aneCWs/ajUX+HypkBTA+c8LGDLnWO2NKq0YD/pnARkAnYGPfUDoHR9gVSp/qRx+Z\n"
"WghiDLZsMwhN1zjtSC0uBWiugF3vTNzYIEFfaPG7Ws3jDrAMMYebQ95JQ+HIBD/R\n"
"PBuHRTBpqKlyDnkSHDHYPiNX3adPoPAcgdF3H2/W0rmoswMWgTlLn1Wu0mrks7/q\n"
"pdWfS6PJ1jty80r2VKsM/Dj3YIDfbjXKdaFU5C+8bhfJGqU3taKauuz0wHVGT3eo\n"
"6FlWkWYtbt4pgdamlwVeZEW+LM7qZEJEsMNPrfC03APKmZsJgpWCDWOKZvkZcvjV\n"
"uYkQ4omYCTX5ohy+knMjdOmdH9c7SpqEWBDC86fiNex+O0XOMEZSa8DA\n"
"-----END CERTIFICATE-----\n";


void WeatherView::draw(DFRobot_RGBLCD1602* lcd) {
    lcd->clear();
    update();
}

void WeatherView::update(){
    time_t seconds = time(NULL);
    if (seconds - lastUpdate < 15*60) {
        lastUpdate=seconds;
    }
    nsapi_error_t r;

    printf("Opening tls socket......... ");fflush(stdout);
    TLSSocket* socket = new TLSSocket();
    if ((r = socket->open(network)) != NSAPI_ERROR_OK) {
        printf("TLS socket open failed (%d)\n", r);
        return;
    }
    printf("Success\n");

    printf("Setting certificate........ ");fflush(stdout);
    if ((r = socket->set_root_ca_cert(SSL_CA_PEM1)) != NSAPI_ERROR_OK) {
        printf("TLS socket setRoot_ca_cert failed (%d)\n", r);
        return;
    }
    printf("Success\n");

    socket->set_hostname("met.no");
    SocketAddress address;
    network->gethostbyname("met.no", &address);
    address.set_port(443);

    printf("Connecting to met.no...... ");fflush(stdout);
    if ((r = socket->connect(address)) != NSAPI_ERROR_OK) {
        printf("TLS socket connect failed (%d) Bruh\n", r);
        return;
    }
    printf("Success\n");

    // Create HTTP request
    const char httpRequest[] = "GET /v2/timezone?apiKey=b0c2c1c553244be58e7bf18736e8106e HTTP/1.1\r\n"
                                "Host: api.met.no\r\n"
                                "Connection: close\r\n"
                                "\r\n";

    nsapi_size_t bytesToSend = strlen(httpRequest);
    nsapi_size_or_error_t sentBytes = 0;
    printf("\nSending HTTP request: \n%s", httpRequest);

    while (bytesToSend) {
        printf("Sendeing................... ");fflush(stdout);
        sentBytes = socket->send(httpRequest + sentBytes, bytesToSend);

        if (sentBytes < 0) {
            break;
        } else {
            printf("%d bytes\n", sentBytes);
        }
        bytesToSend -= sentBytes;
    }

    if (sentBytes < 0) {
        printf("Failed to send HTTP request: %d\n", sentBytes);
        while (1);
    }
    printf("Complete message sent\n\n");

    char buffer[BUFFER_SIZE];
    int remainingBytes = BUFFER_SIZE;
    int receivedBytes = 0;

    printf("Starting to receive\n");
    while (remainingBytes > 0) {
        nsapi_size_or_error_t result = socket->recv(buffer + receivedBytes, remainingBytes);
        if (result == 0) {
            break; // no more data
        }
        if (result < 0) {
            printf("Receive failed: %d\n", result);
            return;
        }
        receivedBytes += result;
        remainingBytes -= result;
    }
    buffer[receivedBytes] = '\0';  // Null-terminate the received data

    // Find start of JSON
    std::string data(buffer, receivedBytes);
    size_t index = data.find("\r\n\r\n");
    if (index == std::string::npos) {
        printf("No header-body separator found\n");
        return;
    }
    index += 4;  
    
    string bufferStr = buffer;
    size_t index1 = bufferStr.find('{');
    size_t index2 = bufferStr.find("}}}");
    buffer[index2 + 3] = '\0'; // gjør at bufferen blir kutta så den ikke forsetter etter json er ferdig
    char* jsonStr = buffer + index1;

    printf("Json:\n \"%s\"\n",jsonStr);

    json jsonData = json::parse(jsonStr, nullptr, false);  

    if (jsonData.is_discarded()) {
        printf("JSON parse error\n");
        return;
    }

   /*if (jsonData.contains("time_zone") && jsonData["time_zone"].is_object() &&
        jsonData.contains("location") && jsonData["location"].is_object()) {
            const auto& timezone = jsonData["time_zone"];
            const auto& location = jsonData["location"];
            lcd.clear();

            if (timezone.contains("date_time_unix") && timezone["date_time_unix"].is_number_float()) {
                double unix_time = timezone["date_time_unix"];
                time_t epoch_time = timezone["date_time_unix"];
                set_time(epoch_time);
                lcd.setCursor(0, 0);
                lcd.printf("Unix epoch time:");
                lcd.setCursor(0, 1);
                lcd.printf("%.3f",unix_time);
                ThisThread::sleep_for(2s);
                lcd.clear();
                } 
        

            if (location.contains("latitude") && location["latitude"].isString() &&
                location.contains("longitude") && location["longitude"].isString()){
                    std::string latitude = location["latitude"];
                    std::string longitude = location["longitude"];
                    lcd.setCursor(0, 0);
                    lcd.printf("Lat: %s", latitude.cStr());
                    lcd.setCursor(0, 1);
                    lcd.printf("Lon: %s", longitude.cStr());
                    ThisThread::sleep_for(2s);
                    lcd.clear();
                }
            

                
            if (location.contains("city") && location["city"].isString()){
                std::string city = location["city"];
                lcd.setCursor(0, 0);
                lcd.printf("City:");
                lcd.setCursor(0, 1);
                lcd.printf("%s",city.cStr());
                ThisThread::sleep_for(2s);
                lcd.clear();
            }
            if (timezone.contains("name") && timezone["name"].isString()) {
                std::string timezoneName = timezone["name"];
                } 

            if (timezone.contains("dstSavings") && timezone["dstSavings"].is_number_integer()) {
                int date_timeSavings = timezone["dstSavings"];
                } 

    }else {
        printf("JSON fields missing or wrong type\n");
        return 1;
        }
        
    }
    */
}

void WeatherView::checkButtons() {
    if (isButtonPressed(1)) {
        menu->prevView();
    } else if (isButtonPressed(2)) {
        menu->nextView();
    } else if (isButtonPressed(3)) {
        update();
    }
}
