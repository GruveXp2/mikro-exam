#include "Menu.h"
#include <cstdio>
#include <memory>
#include "View.h"
#include "ClimateView.h"
#include "TimeView.h"


Menu::Menu(DFRobot_RGBLCD1602& lcd, int& buttonFlags, NetworkInterface* netowrok, const std::string& longitude, const std::string& latitude):
        lcd(&lcd) {
    views.push_back(std::make_unique<TimeView>(this, buttonFlags));
    views.push_back(std::make_unique<ClimateView>(this, buttonFlags));
}

void Menu::draw() {
    views.at(currentViewIndex)->draw(lcd);
}

void Menu::nextView() {
    currentViewIndex++;
    if (currentViewIndex >= views.size()) currentViewIndex = 0;
}

void Menu::prevView() {
    currentViewIndex--;
    if (currentViewIndex < 0) currentViewIndex = views.size() - 1;
}

void Menu::checkButtons() {
    views.at(currentViewIndex)->checkButtons();
}